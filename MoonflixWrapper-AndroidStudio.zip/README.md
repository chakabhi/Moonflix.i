# Moonflix Android Wrapper

A lightweight Android Studio project that wraps the Moonflix website in a hardware-accelerated WebView.

## Features
- Full-screen Moonflix UI
- JavaScript and DOM storage
- Persistent cookies
- Hardware acceleration
- Popup/new-window requests routed back into the same WebView
- External navigation sent to the browser
- Video fullscreen support
- Android back-button navigation

## Build
Open this directory in Android Studio.

1. Let Gradle sync.
2. Connect your Android phone or create an emulator.
3. Run `app`.
4. For an APK: **Build > Generate App Bundles or APKs > Generate APKs**.

The app currently points at:
`https://moonflix.website/`

If the Moonflix domain changes, edit `homeUrl` in:
`app/src/main/kotlin/com/abhi/moonflixwrapper/MainActivity.kt`

## Important
This is a website wrapper, not a copy of Moonflix's backend or content. It does not bypass subscriptions, DRM, authentication, or access controls.
